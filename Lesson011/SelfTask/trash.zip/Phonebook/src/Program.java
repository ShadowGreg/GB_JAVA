import core.entity.base.Person;
import core.entity.base.RecordFields;
import core.entity.phonebook.Phonebook;

import java.io.*;

public class Program {

    public static void main(String[] args) {

        App app = new App(Config.pathDb);
        App.buttonClick();
    }
}

class App {
    private Phonebook<Person, RecordFields> phonebook;

    public App(String pathDb) {
        phonebook = new DBController().readPhonebook();
    }


    public static void buttonClick() {
        System.out.println("TODO btnClick");
    }
}

class DBController<T extends BD> {
    private BD bdType = new Config().bd;
    private String path = Config.pathDb;

    public Phonebook<Person, RecordFields> readPhonebook() {
        return bdType.readBD();
    }

    public void savePhonebook() {
        bdType.saveBD();
    }
}

interface DBable<T1 extends Person, T2 extends RecordFields> {
    Phonebook<T1, T2> readBD();

    void saveBD(Phonebook<T1, T2> phonebook);

}

abstract class BD<T1 extends Person, T2 extends RecordFields> implements DBable {
    public abstract Phonebook<T1, T2> readBD();

    public abstract void saveBD(Phonebook phonebook);
}

class BDReadWriter<T1 extends Person, T2 extends RecordFields> extends BD {
    private String path = Config.pathDb;
    private T1 person = (T1) new Config().person;
    private T2 recordFields = (T2) new Config().phonebookFields;


    @Override
    public Phonebook<T1, T2> readBD() {
        Phonebook<T1, T2> phonebook = new Phonebook<>();

        try {
            File file = new File(path);
            FileReader fr = new FileReader(file);
            BufferedReader reader = new BufferedReader(fr);
            String name = reader.readLine();
            while (name != null) {
                while (person.hasNext()) {
                    var temp = person.next();
                    temp = reader.readLine();
                }
                name = reader.readLine();
            }
            reader.close();
            fr.close();

        } catch (Exception e) {
            System.out.println(e);
            createClanDB();
        }
        return phonebook;
    }

    @Override
    public void saveBD(Phonebook phonebook) {

    }

    private void createClanDB() {
        try {
            File file = new File(path);
            FileWriter fr = new FileWriter(file);
            BufferedWriter writer = new BufferedWriter(fr);
            int lineCount = new Config().person.getFieldsCount()
                    + new Config().phonebookFields.getFieldsCount();
            for (int i = 0; i < lineCount; i++) {
                writer.write("Create,\n");
            }
            writer.close();
            fr.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}