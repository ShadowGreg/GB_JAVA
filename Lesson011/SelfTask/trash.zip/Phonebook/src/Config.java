import core.entity.base.Person;
import core.entity.base.RecordFields;
import core.entity.realistaionV01.NameOfFields;
import core.entity.realistaionV01.PhonebookFields;
import core.entity.realistaionV01.PhoneBookPerson;

public class Config {
    public static String pathDb = "Phonebook/phones.db";
    public static BD bd = new BDReadWriter();
    public NameOfFields fieldsName;
    public RecordFields phonebookFields = new PhonebookFields<>();
    public Person person = new PhoneBookPerson();
}

