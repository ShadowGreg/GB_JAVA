package core.entity.phonebook;

import core.entity.base.Person;
import core.entity.base.RecordFields;

import java.util.HashMap;
import java.util.Map;

public class Phonebook<T1 extends Person,T2 extends RecordFields> {
    private T1 person;
    private T2 recordFields;

    private Map<T1,T2> phoneMap;


    public Phonebook() {
        this.phoneMap = new HashMap<>();
    }

    public void setNewRecord(T1 person,T2 fields){
        phoneMap.put(person,fields);
    }

    public T2 getDataAboutPerson(T1 person){
        return phoneMap.get(person);
    }

    public void delRecord(T1 person){
        phoneMap.remove(person);
    }
}
