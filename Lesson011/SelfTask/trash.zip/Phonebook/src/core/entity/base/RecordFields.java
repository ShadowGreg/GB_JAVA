package core.entity.base;

import java.util.Date;
import java.util.Iterator;

public abstract class RecordFields implements Iterator {
    String phone;
    Date date;
    String description;

    public abstract int getFieldsCount();
}
