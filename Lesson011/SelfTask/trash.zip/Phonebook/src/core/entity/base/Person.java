package core.entity.base;

import java.util.Iterator;
import java.util.Objects;

public abstract class Person<T1 extends Person> implements Iterator {
    public String name;
    public String surname;

    public abstract int getFieldsCount();

    public boolean equals(T1 person) {
        return Objects.equals(person.name, this.name) && Objects.equals(person.surname, this.surname);
    }
    public abstract boolean hasNext();
    public abstract Object next();
}
