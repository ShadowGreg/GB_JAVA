package core.entity.realistaionV01;

import core.entity.base.RecordFields;

import java.util.HashMap;
import java.util.Map;

public class PhonebookFields<T1 extends NameOfFields,T2> extends RecordFields {
    private final int superNumOfFields = 3;

    private final int currentFields = T1.values().length;
    private final int phonebookPersonFields = superNumOfFields + currentFields;

    private int count;
    private Map<T1,T2> records;

    public PhonebookFields(){
        records = new HashMap<>();
    }

    public void addField(T1 fieldName, T2 fieldData) {
        records.put(fieldName, fieldData);
    }
    public T2 getFieldData(T1 fieldName){
        return records.get(fieldName);
    }

    @Override
    public boolean hasNext() {
        count = new FieldsCount().count;
        return false;
    }

    @Override
    public Object next() {
        return null;
    }

    @Override
    public int getFieldsCount() {
        return phonebookPersonFields;
    }

    class FieldsCount{
        public int count;
    }
}
