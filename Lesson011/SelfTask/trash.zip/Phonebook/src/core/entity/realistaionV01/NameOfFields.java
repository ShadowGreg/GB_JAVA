package core.entity.realistaionV01;

public enum NameOfFields {
    email,
    address,
    telegramContact,
    vkContact,
    gitContact,
}
