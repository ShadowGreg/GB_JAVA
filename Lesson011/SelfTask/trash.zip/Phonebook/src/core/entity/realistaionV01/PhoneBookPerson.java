package core.entity.realistaionV01;

import core.entity.base.Person;

import java.util.Iterator;

public class PhoneBookPerson extends Person implements Iterator {
    private final int superNumOfFields = 2;

    private final int currentFields = 1;
    private final int PhonebookPersonFields = superNumOfFields + currentFields;

    private FieldsCount count;

    @Override
    public boolean hasNext() {
        count = new FieldsCount();
        if (count.fieldsCount <= PhonebookPersonFields)
            return true;
        return false;
    }

    public String secondName;

    @Override
    public Object next() {
        switch (count.fieldsCount) {
            case 0:
                return super.name;
            case 1:
                return super.surname;
            default:
                return secondName;
        }
    }

    @Override
    public int getFieldsCount() {
        return PhonebookPersonFields;
    }

    class FieldsCount {
        protected int fieldsCount = 0;
    }
}
