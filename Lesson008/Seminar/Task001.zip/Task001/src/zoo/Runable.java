package zoo;

public interface Runable {
    int getSpeedRun();
}
