package zoo;

public interface Flyable {
    int getSpeedFlyable();
    int getHigh();
}
