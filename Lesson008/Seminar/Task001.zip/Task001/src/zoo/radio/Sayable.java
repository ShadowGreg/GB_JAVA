package zoo.radio;

public interface Sayable {
     String say();
}
