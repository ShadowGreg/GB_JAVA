package zoo.radio;

public class Radio implements Sayable{

    @Override
    public String say() {
        return "Bla Bla Bla!";
    }
}
